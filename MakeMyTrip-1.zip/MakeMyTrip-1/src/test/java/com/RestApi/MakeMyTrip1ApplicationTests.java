package com.RestApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakeMyTrip1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
